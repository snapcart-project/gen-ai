const { createClient } =
require('@supabase/supabase-js');
const supabaseUrl = 
"https://zmfofgjtnhdwkkujgknv.supabase.co";
const supabaseKey = 
"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InptZm9mZ2p0bmhkd2trdWpna252Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc3NDU1MTQsImV4cCI6MjA3MzMyMTUxNH0.moxw1V_ytpo0rrDocZIVHtRIym26Ruero2LIKwtq5O0";
const supabase = createClient(supabaseUrl,supabaseKey);
module.exports = supabase;