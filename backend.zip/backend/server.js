const express = require('express'); // import express
const supabase = require('./db');   // import supabase client

const app = express();              // create express app
app.use(express.json());            // middleware to parse JSON

// Test route to check if server is running
app.get('/', (req, res) => {
  res.send('✅ Server is running!');
});

// Test route to check DB connection
app.get('/test-db', async (req, res) => {
  const { data, error } = await supabase.from('products').select('*');
  if (error) return res.status(500).json({ error: error.message });
  res.json({ message: 'DB connected!', size: data.length });
});

// Start the server
app.listen(3000, () => {
  console.log('✅ Server running on http://localhost:3000');
});
// POST /product - insert a new product
app.post('/product', async (req, res) => {
  const { name, artisan, price, image_url } = req.body; // extract from request body

  const { data, error } = await supabase
    .from('products')
    .insert([{ name, artisan, price, image_url }]);

  if (error) return res.status(400).json({ error: error.message });
  res.status(201).json({ message: 'Product added!', data });
});

// GET /product/:id - fetch a product by its id
app.get('/product/:id', async (req, res) => {
  const { id } = req.params;

  const { data, error } = await supabase
    .from('products')
    .select('*')
    .eq('id', id)
    .single();

  if (error) return res.status(404).json({ error: error.message });
  res.json({ message: 'Product found!', data });
});
app.get("/products", async (req, res) => {
  try {
    const { data, error } = await supabase
      .from("products") // your table name
      .select("*");

    if (error) {
      return res.status(500).json({ error: error.message });
    }

    res.json(data); // send all rows back as JSON
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
app.get("/join-live", (req, res) => {
  const meetLink = "https://meet.google.com/vvw-cqnz-dvx"; // Replace with your actual Meet link
  res.redirect(meetLink);
});


