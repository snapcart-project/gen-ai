// photoPipeline.js
const { VertexAI, HarmCategory, HarmBlockThreshold } = require('@google-cloud/vertexai');
const vision = require('@google-cloud/vision');
const fs = require('fs');
const path = require('path');

// This line is no longer needed after setting up ADC
// process.env.GOOGLE_APPLICATION_CREDENTIALS = path.join(__dirname, 'gcp-key.json');

// Using your actual Google Cloud Project ID
const projectId = 'hazel-quanta-472611-h6'; 
// Using a supported location for the model
const location = 'asia-southeast1';

// Initialize the Vertex AI client
const vertexAI = new VertexAI({ project: projectId, location });
const generativeModel = vertexAI.getGenerativeModel({
  model: 'imagen-edit@001',
  safetySettings: [{ category: HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT, threshold: HarmBlockThreshold.BLOCK_LOW_AND_ABOVE }],
});

const processPhoto = async (imagePath) => {
  try {
    console.log('Using a special version of the code!');
    console.log('Starting photo enhancement and tagging...');

    // Initialize the Cloud Vision API client inside the async function
    const visionClient = new vision.ImageAnnotatorClient();

    // Step A: Photo enhancement (background cleanup, relight)
    // Read the original image file
    const imageBuffer = fs.readFileSync(imagePath);
    const base64Image = imageBuffer.toString('base64');
    const mimeType = 'image/jpeg';

    // Remove the background with Vertex AI
    console.log('Removing background...');
    const removeBgRequest = {
      contents: [
        {
          role: 'user',
          parts: [{ inlineData: { mimeType, data: base64Image } }],
        },
        {
          role: 'user',
          parts: [{ text: "Remove the background from the product." }],
        }
      ],
    };
    const [removeBgResponse] = await generativeModel.generateContent(removeBgRequest);
    const noBgImageBytes = removeBgResponse.candidates[0].content.parts[0].inlineData.data;
    const noBgImagePath = 'temp-no-bg-image.png';
    fs.writeFileSync(noBgImagePath, Buffer.from(noBgImageBytes, 'base64'));
    console.log('Background removed. Temp file saved to:', noBgImagePath);
    
    // Relight the product with Vertex AI
    console.log('Relighting the product...');
    const noBgImageBuffer = fs.readFileSync(noBgImagePath);
    const noBgBase64 = noBgImageBuffer.toString('base64');
    const relightRequest = {
      contents: [
        {
          role: 'user',
          parts: [
            { inlineData: { mimeType: 'image/png', data: noBgBase64 } },
            { text: "Relight the product with soft, professional studio lighting from the top-right." }
          ],
        },
      ],
    };
    const [relightResponse] = await generativeModel.generateContent(relightRequest);
    const finalImageBytes = relightResponse.candidates[0].content.parts[0].inlineData.data;
    const finalImagePath = 'enhanced-image.jpg';
    fs.writeFileSync(finalImagePath, Buffer.from(finalImageBytes, 'base64'));
    console.log(`Image enhancement complete. Final image saved to: ${finalImagePath}`);
    
    // Step B: Tag extraction
    console.log('Starting tag extraction...');
    const [result] = await visionClient.annotateImage({
      image: { content: fs.readFileSync(finalImagePath) },
      features: [{ type: 'LABEL_DETECTION' }, { type: 'OBJECT_LOCALIZATION' }],
    });

    const tags = [
      ...result.labelAnnotations.map(label => label.description),
      ...result.localizedObjectAnnotations.map(obj => obj.name),
    ];

    const uniqueTags = [...new Set(tags)];
    console.log('Extracted and unique tags:', uniqueTags);

    return {
      enhancedImage: finalImagePath,
      tags: uniqueTags,
    };

  } catch (error) {
    console.error('An error occurred during photo processing:', error);
    return null;
  }
};

// This section runs the function
const testImagePath = 'testphoto.jpg'; // Place your test image here
processPhoto(testImagePath);